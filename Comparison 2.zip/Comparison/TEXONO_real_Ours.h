double Factor=0.75;
double TEXONO_real_chiN[12][2] = {
2.35,1e-28,
3,6e-29,
4,3.2e-29,
5,2e-29,
7,1.2e-29,
9,8.2e-30,
11,5e-30,
13,3e-30,
15,2.5e-30,
17,2.2e-30,
19,2.5e-30,
20,2.5e-30,
};//New with the shielding
